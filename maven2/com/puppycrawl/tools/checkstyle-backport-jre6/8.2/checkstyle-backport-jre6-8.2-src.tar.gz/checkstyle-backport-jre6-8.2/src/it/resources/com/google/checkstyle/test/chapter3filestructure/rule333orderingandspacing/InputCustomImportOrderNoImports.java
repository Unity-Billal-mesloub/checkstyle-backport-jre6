package com.google.checkstyle.test.chapter3filestructure.rule333orderingandspacing;

public class InputCustomImportOrderNoImports {
}
