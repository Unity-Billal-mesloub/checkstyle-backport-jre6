package com.puppycrawl.tools.checkstyle.checks.metrics.inputs.a.aa;

public class AAClass {
}
