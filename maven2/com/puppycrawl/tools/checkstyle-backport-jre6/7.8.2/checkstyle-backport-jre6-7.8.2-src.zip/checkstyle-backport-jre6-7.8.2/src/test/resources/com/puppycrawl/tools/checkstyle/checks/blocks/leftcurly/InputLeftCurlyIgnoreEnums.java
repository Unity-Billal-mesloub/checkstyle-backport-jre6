package com.puppycrawl.tools.checkstyle.checks.blocks.leftcurly;

public class InputLeftCurlyIgnoreEnums {
    enum Colors {RED,
        BLUE,
        GREEN
    }

    enum Languages {
        JAVA,
        PHP,
        SCALA,
        C,
        PASCAL
    }
}
