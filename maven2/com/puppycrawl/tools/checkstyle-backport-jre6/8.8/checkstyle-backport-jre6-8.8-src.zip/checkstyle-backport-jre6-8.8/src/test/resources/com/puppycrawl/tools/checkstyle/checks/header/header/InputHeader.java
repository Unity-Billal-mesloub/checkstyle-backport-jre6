package com.puppycrawl.tools.checkstyle.checks.header.header; class InputHeader {} // One line test
