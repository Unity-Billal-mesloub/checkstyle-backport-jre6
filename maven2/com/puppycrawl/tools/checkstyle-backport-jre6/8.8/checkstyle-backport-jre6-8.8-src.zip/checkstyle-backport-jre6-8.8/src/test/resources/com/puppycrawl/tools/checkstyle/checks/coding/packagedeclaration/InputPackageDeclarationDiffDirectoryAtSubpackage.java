package com.puppycrawl.tools.checkstyle.checks.coding.packagedeclaration.subpackage;

public class InputPackageDeclarationDiffDirectoryAtSubpackage {
    public String value;

    private void get(){
    }
}
