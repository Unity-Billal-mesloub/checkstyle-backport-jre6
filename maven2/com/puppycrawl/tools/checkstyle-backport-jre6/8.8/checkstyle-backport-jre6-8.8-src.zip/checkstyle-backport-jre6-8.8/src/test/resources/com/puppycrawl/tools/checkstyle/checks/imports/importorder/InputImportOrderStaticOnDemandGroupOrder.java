package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

import static java.lang.Math.*;
import static org.antlr.v4.runtime.CommonToken.*;

import org.*;

import java.util.Set;
import org.junit.Test;

public class InputImportOrderStaticOnDemandGroupOrder
{

}
