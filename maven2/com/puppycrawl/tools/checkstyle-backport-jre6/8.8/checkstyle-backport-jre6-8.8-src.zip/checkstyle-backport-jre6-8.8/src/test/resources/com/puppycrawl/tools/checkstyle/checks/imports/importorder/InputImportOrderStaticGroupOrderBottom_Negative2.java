package com.puppycrawl.tools.checkstyle.checks.imports.importorder;

import org.*;

import static java.lang.Math.PI;
import static org.antlr.v4.runtime.Recognizer.EOF;

import java.util.Set;

import static java.util.Set.*;

public class InputImportOrderStaticGroupOrderBottom_Negative2
{

}
