package com.puppycrawl.tools.checkstyle.checks.coding.multiplestringliterals;

public class InputMultipleStringLiteralsNoWarnings {
    private final String m4 = "" + "";
}
