package com.puppycrawl.tools.checkstyle.checks.imports.unusedimports;

import java.util.Map; // OK
import java.util.List; // VIOLATION

/**
 * Use {@link Map.Entry} in this javadoc.
 */
public class InputUnusedImportsJavadocQualifiedName {}
