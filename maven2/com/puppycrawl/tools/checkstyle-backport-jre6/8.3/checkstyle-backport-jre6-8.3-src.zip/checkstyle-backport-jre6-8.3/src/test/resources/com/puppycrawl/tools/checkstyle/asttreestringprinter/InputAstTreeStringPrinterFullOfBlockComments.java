/*0*//*1*/package/*2*/ com/*3*/./*4*/puppycrawl/*5*/./*6*/tools/*7*/./*8*/checkstyle/*9*/./*10*/astprinter/*11*/;/*12*/
/*13*/
/*14*/public/*15*/ class /*16*/InputAstTreeStringPrinterFullOfBlockComments /*49*/{/*17*/
	/*18*/
	/*19*/public/*20*/ static/*
21
*/ String/*22*/ main/*23*/(/*24*/String/*25*/[/*26*/]/*27*/ args/*28*/)/*29*/ {/*30*/
		/*31*/String /*32*/line /*33*/= /*34*/"/*I'm NOT comment*/blabla"/*35*/;/*36*/
		/*37*/String/*38*/./*  39  */CASE_INSENSITIVE_ORDER/*40*/./*41*/equals/*42*/(/*43*/line/*44*/)/*45*/;/*46*/
		Integer[] array = null;
		/*50*/for/*51*/ (/*52*/Integer/*53*/ i/*54*/:/*55*/ array/*56*/)/*57*/ {/*58*/
		    /*59*/
		}/*60*/
		return line;
	}/*47*/
}/*48*/
/*61*/
