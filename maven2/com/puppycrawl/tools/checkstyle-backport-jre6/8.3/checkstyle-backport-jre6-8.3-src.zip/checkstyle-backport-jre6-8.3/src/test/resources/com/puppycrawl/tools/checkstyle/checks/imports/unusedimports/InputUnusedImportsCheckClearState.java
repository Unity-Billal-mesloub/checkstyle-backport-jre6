package com.puppycrawl.tools.checkstyle.checks.imports.unusedimports;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class InputUnusedImportsCheckClearState {}
