package com.puppycrawl.tools.checkstyle.checks.metrics.classfanoutcomplexity.inputs.a.ab;

public class ABClass {
}
