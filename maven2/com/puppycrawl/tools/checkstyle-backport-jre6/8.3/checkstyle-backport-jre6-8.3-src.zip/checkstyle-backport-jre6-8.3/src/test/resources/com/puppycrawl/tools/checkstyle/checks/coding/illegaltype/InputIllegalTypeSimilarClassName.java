package com.puppycrawl.tools.checkstyle.checks.coding.illegaltype;

public class InputIllegalTypeSimilarClassName {
	private TreeSet example;

	private static class TreeSet {
	}
}
