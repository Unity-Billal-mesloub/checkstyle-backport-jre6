public class InputAstTreeStringPrinterJavadocPosition {
    void method() {
	/**
	This is a method
	@return void
	<html
	*/
    }
}
