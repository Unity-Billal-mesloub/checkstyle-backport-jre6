package com.puppycrawl.tools.checkstyle.checks.design.visibilitymodifier;

import com.google.common.collect.*;
//config.immutableClassName=com.google.google.common.ImmutableSet
public final class InputVisibilityModifierImmutableStarImport2
{
    public final ImmutableSet<String> set = null; // No warning here
}
