package com.puppycrawl.tools.checkstyle.checks.metrics.classdataabstractioncoupling.inputs.b;

public class BClass {
}
