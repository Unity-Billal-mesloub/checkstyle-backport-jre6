package com.puppycrawl.tools.checkstyle.checks.metrics.classfanoutcomplexity.inputs.a.aa;

public class AAClass {
}
