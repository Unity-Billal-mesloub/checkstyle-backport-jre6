package com.puppycrawl.tools.checkstyle.checks.design.onetoplevelclass;

public enum InputOneTopLevelClassEnum {
    VALUE1, VALUE2;
}
