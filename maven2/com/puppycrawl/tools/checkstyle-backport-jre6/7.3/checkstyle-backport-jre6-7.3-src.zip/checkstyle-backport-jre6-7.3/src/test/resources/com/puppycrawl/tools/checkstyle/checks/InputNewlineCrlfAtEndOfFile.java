////////////////////////////////////////////////////////////////////////////////
// Test case file for checkstyle.
// Created: 2015
////////////////////////////////////////////////////////////////////////////////
package com.puppycrawl.tools.checkstyle.checks;

/**
 * Test case for detection of an existing CRLF newline at EOF, using the 
 * NewlineAtEndOfFileCheck.
 * @author Martin Steiger
 **/
public interface InputNewlineCrlfAtEndOfFile
{
}
