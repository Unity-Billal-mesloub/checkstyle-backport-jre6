/**
 * This is a valid package documentation.  <--- See the period after the
 * first sentence.
 *
 * <p>
 * hurray for javadocs in html
 * <br>
 * with a legacy non-closed br element
 * </p>
 */
@Deprecated
package com.puppycrawl.tools.checkstyle.checks.javadoc.pkginfo.annotation;
