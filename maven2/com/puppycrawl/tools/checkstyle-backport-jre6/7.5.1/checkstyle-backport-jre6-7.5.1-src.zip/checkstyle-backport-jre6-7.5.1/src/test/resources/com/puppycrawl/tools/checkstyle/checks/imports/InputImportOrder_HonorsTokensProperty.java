package com.puppycrawl.tools.checkstyle.checks.imports;

import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import static java.awt.Button.ABORT;
import java.awt.Dialog;
import java.awt.Button;

public class InputImportOrder_HonorsTokensProperty {
}
