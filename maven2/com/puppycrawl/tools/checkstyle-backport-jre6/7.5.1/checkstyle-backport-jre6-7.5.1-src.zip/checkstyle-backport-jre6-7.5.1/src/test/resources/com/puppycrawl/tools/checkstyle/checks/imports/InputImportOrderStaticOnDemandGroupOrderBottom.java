package com.puppycrawl.tools.checkstyle.checks.imports;

import org.antlr.v4.runtime.*;

import java.util.Set;

import static java.lang.Math.*;
import static org.antlr.v4.runtime.CommonToken.*;

public class InputImportOrderStaticOnDemandGroupOrderBottom
{

}
