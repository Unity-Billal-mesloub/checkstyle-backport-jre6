package com.puppycrawl.tools.checkstyle.checks.whitespace;

import java.util.List;

public class InputGh47
{
    public List<List<String>[]> listOfListOFArrays;
}
