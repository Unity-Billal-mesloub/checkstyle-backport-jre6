package com.puppycrawl.tools.checkstyle.checks.sizes;

/**Contains empty inner class for OuterTypeNumberCheckTest*/
public class InputOuterTypeNumber {

    /** Just empty inner class*/
    private class InnerClass {
        // Do nothing
    }
}
