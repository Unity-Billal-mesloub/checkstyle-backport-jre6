package com.puppycrawl.tools.checkstyle.grammars;
/**
 * Input for grammar test.
 */
public class InputGrammar
{
    int ÃЯ = 1; // illegal, unless UTF-8
}
