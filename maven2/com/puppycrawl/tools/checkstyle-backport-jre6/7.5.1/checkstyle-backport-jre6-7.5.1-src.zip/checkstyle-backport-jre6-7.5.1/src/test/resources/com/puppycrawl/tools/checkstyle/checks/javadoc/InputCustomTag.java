package com.puppycrawl.tools.checkstyle.checks.javadoc;

public class InputCustomTag {
    /**
     * {@customTag}
     */
    void customTag() {}

    /** {@customTag} */
    void customTag2() {}
}
