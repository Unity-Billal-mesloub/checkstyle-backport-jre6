package com.puppycrawl.tools.checkstyle.checks.imports;

import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

public class InputCustomImportOrderNoValid {
}
