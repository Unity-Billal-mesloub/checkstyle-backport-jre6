package com.puppycrawl.tools.checkstyle.checks.whitespace;import java.util.List;

import java.util.Calendar;
import java.util.Date;

public class InputEmptyLineSeparatorMultipleImportEmptyClass
{
}
