package com.puppycrawl.tools.checkstyle;

/**javadoc*/
class InputAstTreeStringPrinterJavadoc {
    /*not javadoc*/
    void m(){}
}