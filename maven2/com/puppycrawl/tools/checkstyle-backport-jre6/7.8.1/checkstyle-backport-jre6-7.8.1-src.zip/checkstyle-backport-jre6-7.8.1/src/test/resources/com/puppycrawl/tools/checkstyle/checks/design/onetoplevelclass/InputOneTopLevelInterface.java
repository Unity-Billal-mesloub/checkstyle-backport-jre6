package com.puppycrawl.tools.checkstyle.checks.design.onetoplevelclass;

public interface InputOneTopLevelInterface {
    int foo();
}
