package com.puppycrawl.tools.checkstyle.checks.design.onetoplevelclass;

enum InputOneTopLevelEnum2inner1 {
    VALUE1, VALUE2;
}

public enum InputOneTopLevelEnum2 {
    VALUE1, VALUE2;
}

enum InputOneTopLevelEnum2inner2 {
    VALUE1, VALUE2;
}
