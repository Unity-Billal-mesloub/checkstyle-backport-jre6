package com.puppycrawl.tools.checkstyle.checks.whitespace.nolinewrap;

import com.puppycrawl.tools.checkstyle.TreeWalker;

import javax.accessibility.AccessibleAttributeSequence;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

import static java.math.BigInteger.ZERO;

public class InputNoLineWrapGood {

	public void fooMethod() {
		//
	}
}
