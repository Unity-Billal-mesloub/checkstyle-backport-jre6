package com.puppycrawl.tools.checkstyle.checks.design.onetoplevelclass;

public enum InputOneTopLevelEnum {
    VALUE1, VALUE2;
}
