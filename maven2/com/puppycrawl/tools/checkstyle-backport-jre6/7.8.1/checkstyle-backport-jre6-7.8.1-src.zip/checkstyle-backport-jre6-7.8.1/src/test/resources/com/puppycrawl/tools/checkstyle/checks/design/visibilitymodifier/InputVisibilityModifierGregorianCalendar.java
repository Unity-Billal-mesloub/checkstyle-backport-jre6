package com.puppycrawl.tools.checkstyle.checks.design.visibilitymodifier;

public class InputVisibilityModifierGregorianCalendar
{
    class SubCalendar {
        
    }
}
