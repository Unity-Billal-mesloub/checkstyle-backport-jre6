/**
* some text
*/
public class InputAstTreeStringPrinterJavaAndJavadoc {

} 
