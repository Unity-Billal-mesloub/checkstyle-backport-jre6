package com.puppycrawl.tools.checkstyle.ant;

/**
 * @incomplete Some javadoc
 */
public final class InputCheckstyleAntTaskError {
    private static final String FOO = "This line is longer then 70 characters.";

    private static final String FOOO = "This line is longer then 70 characters.";
}
