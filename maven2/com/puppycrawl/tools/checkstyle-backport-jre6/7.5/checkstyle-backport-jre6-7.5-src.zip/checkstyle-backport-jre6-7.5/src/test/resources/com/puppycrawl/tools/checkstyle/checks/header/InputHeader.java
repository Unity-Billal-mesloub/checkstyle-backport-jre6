package com.puppycrawl.tools.checkstyle.checks.header; class InputHeader {} // One line test
