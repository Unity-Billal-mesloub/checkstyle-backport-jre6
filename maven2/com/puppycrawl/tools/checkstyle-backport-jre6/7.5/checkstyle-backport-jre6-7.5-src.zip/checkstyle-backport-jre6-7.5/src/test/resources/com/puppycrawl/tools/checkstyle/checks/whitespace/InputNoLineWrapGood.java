package com.puppycrawl.tools.checkstyle.checks.whitespace;

import com.puppycrawl.tools.checkstyle.TreeWalker;

import javax.accessibility.AccessibleAttributeSequence;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public class InputNoLineWrapGood {
    
	public void fooMethod() {
		//
	}
}
