package com.puppycrawl.tools.checkstyle.api;

public class InputClearDetailAstLazyLoadCache {

    public
    /*
     * Javadoc comment
     */
    static void foo() {
        return;
    }
}
