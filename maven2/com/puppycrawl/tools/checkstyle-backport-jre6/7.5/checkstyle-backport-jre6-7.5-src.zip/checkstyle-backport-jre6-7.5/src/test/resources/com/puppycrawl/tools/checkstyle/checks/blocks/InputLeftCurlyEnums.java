package com.puppycrawl.tools.checkstyle.checks.blocks;

public class InputLeftCurlyEnums {
    enum Colors {RED,
        BLUE,
        GREEN
    }

    enum Languages {
        JAVA,
        PHP,
        SCALA,
        C,
        PASCAL
    }
}
