/** Comment */ package com.puppycrawl.tools.checkstyle.checks.indentation;//indent:0 exp:>=0

public class InputPackageDeclaration3 {}//indent:0 exp:0
