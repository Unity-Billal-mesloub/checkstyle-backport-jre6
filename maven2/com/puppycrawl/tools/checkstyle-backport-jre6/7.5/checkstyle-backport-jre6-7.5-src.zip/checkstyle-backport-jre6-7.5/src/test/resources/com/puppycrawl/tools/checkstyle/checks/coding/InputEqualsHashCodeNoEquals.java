package com.puppycrawl.tools.checkstyle.checks.coding;

public class InputEqualsHashCodeNoEquals {
    public int hashCode() {
        return 1;
    }
}
