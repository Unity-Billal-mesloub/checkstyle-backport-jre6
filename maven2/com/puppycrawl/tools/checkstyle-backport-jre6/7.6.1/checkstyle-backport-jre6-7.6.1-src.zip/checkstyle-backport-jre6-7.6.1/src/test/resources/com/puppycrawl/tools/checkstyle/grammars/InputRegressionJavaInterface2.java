package com.puppycrawl.tools.checkstyle.grammars;

public interface InputRegressionJavaInterface2 {
}
interface MyInterface<T> {
}
