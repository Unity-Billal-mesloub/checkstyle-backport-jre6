package com.puppycrawl.tools.checkstyle.checks.imports;


public class InputCustomImportOrder_NoImports {
}
