/**
* class javadoc
*/
class InputAstTreeStringPrinterJavaAndMethodsJavadoc {

    /** attribute javadoc*/
    int attribute;

    /**
    * method javadoc
    */
    public void method() { }

}
