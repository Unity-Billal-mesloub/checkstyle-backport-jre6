package com.puppycrawl.tools.checkstyle.checks.javadoc;

/**
 * InputUnusedParamInJavadocForClass.
 *
 * @param BAD This is bad.
 * @param <BAD> This doesn't exist.
 * @param
 */
public class InputUnusedParamInJavadocForClass {
}
