package com.puppycrawl.tools.checkstyle.grammars.java8;

import java.util.List;

public class InputAnnotations1 {
	
	@NonNull
	List<Integer> numbers;

	@interface NonNull {

	}
	
}
