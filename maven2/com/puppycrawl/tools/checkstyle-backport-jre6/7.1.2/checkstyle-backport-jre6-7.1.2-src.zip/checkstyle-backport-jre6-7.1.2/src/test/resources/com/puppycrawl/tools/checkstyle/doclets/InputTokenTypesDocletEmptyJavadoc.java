package com.puppycrawl.tools.checkstyle.doclets;

import com.puppycrawl.tools.checkstyle.grammars.GeneratedJavaTokenTypes;

public class InputTokenTypesDocletEmptyJavadoc {

    /**
     *
     */
    public static final int VARIABLE_DEF = GeneratedJavaTokenTypes.VARIABLE_DEF; // must have javadoc
}
