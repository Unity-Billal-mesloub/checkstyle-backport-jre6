package com.puppycrawl.tools.checkstyle.checks.javadoc;
/** Javadoc for import */
import java.io.Serializable;
