package com.puppycrawl.tools.checkstyle.checks.naming;

class inputHeaderClass {

    public interface inputHeaderInterface {};
//comment
    public enum inputHeaderEnum { one, two };

    public @interface inputHeaderAnnotation {};

}
