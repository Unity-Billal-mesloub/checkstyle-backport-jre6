 package com.puppycrawl.tools.checkstyle.checks.indentation;//indent:1 exp:0 warn

public class InputPackageDeclaration {}//indent:0 exp:0
