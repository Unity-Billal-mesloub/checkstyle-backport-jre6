package com.puppycrawl.tools.checkstyle.checks.design;

class InputOneTopLevelClassNoPublic
{

}

class InputOneTopLevelClassNoPublic2
{

}