package com.puppycrawl.tools.checkstyle.checks.imports;

import java.io.File;

import org.*;
import org.myOrgorgan.Test;

public class InputImportOrder_MultiplePatternMatches {
}
