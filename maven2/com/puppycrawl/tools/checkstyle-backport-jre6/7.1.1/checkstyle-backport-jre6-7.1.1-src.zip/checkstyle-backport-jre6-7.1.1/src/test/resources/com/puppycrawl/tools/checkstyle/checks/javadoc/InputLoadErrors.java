package com.puppycrawl.tools.checkstyle.checks.javadoc;

public class InputLoadErrors
{
    /**
     * aasdf
     * @throws InvalidExceptionName exception that cannot be loaded
     */
    void method() {}
}
