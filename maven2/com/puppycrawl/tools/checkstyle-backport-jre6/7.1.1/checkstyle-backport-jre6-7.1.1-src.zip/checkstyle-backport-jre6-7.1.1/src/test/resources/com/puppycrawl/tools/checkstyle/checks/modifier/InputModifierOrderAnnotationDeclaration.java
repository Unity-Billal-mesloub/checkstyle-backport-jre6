package com.puppycrawl.tools.checkstyle.checks.modifier;

public @InterfaceAnnotation @interface InputModifierOrderAnnotationDeclaration {
    int getValue();
}

@interface InterfaceAnnotation {}
