package com.puppycrawl.tools.checkstyle.checks.whitespace;

public class InputNoWhiteSpaceAfterFormerNpe
{
    private int[] getSome() {
        return new int[4];
    }
}
