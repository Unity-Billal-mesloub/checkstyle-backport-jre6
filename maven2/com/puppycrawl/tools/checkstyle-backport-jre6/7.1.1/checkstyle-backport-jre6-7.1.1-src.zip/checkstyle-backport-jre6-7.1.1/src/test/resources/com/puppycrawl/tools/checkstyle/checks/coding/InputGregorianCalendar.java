package com.puppycrawl.tools.checkstyle.checks.coding;

public class InputGregorianCalendar
{
    class SubCalendar {
        
    }
}
