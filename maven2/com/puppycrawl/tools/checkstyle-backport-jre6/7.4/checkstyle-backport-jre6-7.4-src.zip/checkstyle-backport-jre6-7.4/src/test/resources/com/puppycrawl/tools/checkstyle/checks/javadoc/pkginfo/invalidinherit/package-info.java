/**
 * {@inheritDoc} Where are we inheriting from
 */
package com.puppycrawl.tools.checkstyle.checks.javadoc.pkginfo.invalidinherit;
